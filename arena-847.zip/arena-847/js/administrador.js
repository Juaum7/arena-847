/* ==========================================================================
   administrador.js — Painel do administrador
   Aulas: criar, editar, cancelar/reativar, excluir e gerenciar inscritos.
   Alunos: cadastrar, desativar/reativar e excluir contas.
   O HTML dos cartões, listas e janelas está no administrador.html.
   ========================================================================== */

(async function () {
  const usuario = await Sessao.exigir('admin');
  if (!usuario) return;

  // Elementos da página
  const listaProximas = document.getElementById('lista-proximas');
  const listaAnteriores = document.getElementById('lista-anteriores');
  const listaAlunos = document.getElementById('lista-alunos');
  const formAluno = document.getElementById('form-aluno');

  const dialogoAula = document.getElementById('dialogo-aula');
  const formAula = document.getElementById('form-aula');

  const dialogoGerenciar = document.getElementById('dialogo-gerenciar');
  const areaGerenciar = document.getElementById('gerenciar');
  const listaInscritos = document.getElementById('lista-inscritos');
  const selectAluno = document.getElementById('select-aluno');
  const formAdicionar = document.getElementById('form-adicionar');

  let aulaEmEdicao = null;       // id da aula aberta no formulário (null = nova aula)
  let aulaGerenciada = null;     // id da aula aberta na janela "Gerenciar aula"

  /** Desativa um botão enquanto a ação dele estiver em andamento. */
  async function comBotaoOcupado(botao, acao) {
    if (botao) botao.disabled = true;
    try {
      return await acao();
    } finally {
      if (botao) botao.disabled = false;
    }
  }

  // =========================================================== EXIBIÇÃO

  function dadosCartao(aula) {
    const dados = dadosDaAula(aula);
    dados.apagado = aula.cancelada || dados.passou;
    return dados;
  }

  function ligarBotaoGerenciar(cartao, aula) {
    cartao.querySelector('[data-acao="gerenciar"]').dataset.aulaId = aula.id;
  }

  async function mostrarAulas() {
    const [proximas, anteriores] = await Promise.all([
      Dados.listarAulas({ futuras: true }),
      Dados.listarAulas({ futuras: false }),
    ]);

    preencherLista(listaProximas, 'modelo-aula', proximas.map(dadosCartao),
      document.getElementById('sem-proximas'), ligarBotaoGerenciar);

    document.getElementById('bloco-anteriores').hidden = anteriores.length === 0;
    document.getElementById('contador-anteriores').textContent = anteriores.length;
    preencherLista(listaAnteriores, 'modelo-aula', anteriores.map(dadosCartao), null, ligarBotaoGerenciar);
  }

  async function mostrarResumo() {
    const resumo = await Dados.resumo();
    document.getElementById('resumo-aulas').textContent = resumo.proximasAulas;
    document.getElementById('resumo-ocupadas').textContent = resumo.vagasOcupadas;
    document.getElementById('resumo-totais').textContent = resumo.vagasTotais;
    document.getElementById('resumo-alunos').textContent = resumo.alunos;
  }

  async function mostrarAlunos() {
    const alunos = await Dados.listarAlunos();
    document.getElementById('contador-alunos').textContent = alunos.length;

    const itens = alunos.map((aluno) => ({
      ...aluno,
      inicial: aluno.username.charAt(0),
      textoInscricoes: aluno.totalInscricoes === 1 ? '1 inscrição' : `${aluno.totalInscricoes} inscrições`,
      desativada: !aluno.ativo,
      textoAtivacao: aluno.ativo ? 'Desativar' : 'Reativar',
    }));

    preencherLista(listaAlunos, 'modelo-aluno', itens, document.getElementById('sem-alunos'),
      (item, aluno) => {
        item.querySelectorAll('[data-acao="excluir"], [data-acao="ativacao"]').forEach((botao) => {
          botao.dataset.alunoId = aluno.id;
          botao.dataset.nome = aluno.username;
          botao.dataset.ativo = String(aluno.ativo);
        });
      });
  }

  const atualizarTudo = semSobreposicao(async () => {
    try {
      await Promise.all([mostrarResumo(), mostrarAulas(), mostrarAlunos()]);
      if (dialogoGerenciar.open) await mostrarGerenciar();
    } catch (erro) {
      notificarErro(erro);
    }
  });

  // ============================================ JANELA: CRIAR / EDITAR

  async function abrirFormularioAula(aulaId = null) {
    aulaEmEdicao = aulaId;
    formAula.reset();
    limparErrosDoFormulario(formAula);

    const titulo = document.getElementById('titulo-dialogo-aula');
    const botaoSalvar = document.getElementById('botao-salvar-aula');
    const ajudaVagas = document.getElementById('ajuda-vagas');

    if (aulaId === null) {
      titulo.textContent = 'Nova aula';
      botaoSalvar.textContent = 'Criar aula';
      formAula.data.min = Dados.hojeTexto();
      formAula.maxAlunos.min = 1;
      ajudaVagas.textContent = 'Quantidade máxima de alunos nesta aula (1 a 100).';
    } else {
      let aula;
      try {
        aula = await Dados.buscarAula(aulaId);
      } catch (erro) {
        notificarErro(erro);
        return;
      }
      if (!aula) {
        notificar('Aula não encontrada.', 'erro');
        await atualizarTudo();
        return;
      }
      titulo.textContent = 'Editar aula';
      botaoSalvar.textContent = 'Salvar alterações';
      formAula.modalidade.value = aula.modalidade;
      formAula.data.removeAttribute('min');
      formAula.data.value = aula.data;
      formAula.horario.value = aula.horario;
      formAula.maxAlunos.value = aula.maxAlunos;
      formAula.maxAlunos.min = Math.max(1, aula.inscritos);
      ajudaVagas.textContent = aula.inscritos > 0
        ? `Esta aula já tem ${aula.inscritos} aluno(s) inscrito(s); o limite não pode ser menor que isso.`
        : 'Quantidade máxima de alunos nesta aula (1 a 100).';
    }

    dialogoAula.showModal();
  }

  formAula.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    limparErrosDoFormulario(formAula);
    const campos = lerFormulario(formAula);
    const botaoSalvar = document.getElementById('botao-salvar-aula');

    try {
      await comBotaoOcupado(botaoSalvar, async () => {
        if (aulaEmEdicao === null) {
          await Dados.criarAula(campos);
          notificar('Aula criada com sucesso.');
        } else {
          await Dados.atualizarAula(aulaEmEdicao, campos);
          notificar('Aula atualizada.');
        }
      });
      dialogoAula.close();
      await atualizarTudo();
    } catch (erro) {
      mostrarErrosNoFormulario(formAula, erro);
    }
  });

  document.getElementById('botao-nova-aula').addEventListener('click', () => abrirFormularioAula());
  document.querySelector('[data-acao="nova-aula"]').addEventListener('click', () => abrirFormularioAula());

  // ============================================ JANELA: GERENCIAR AULA

  async function mostrarGerenciar() {
    const idPedido = aulaGerenciada;
    const [aula, inscritos, disponiveis] = await Promise.all([
      Dados.buscarAula(idPedido),
      Dados.inscritosDaAula(idPedido),
      Dados.alunosNaoInscritos(idPedido),
    ]);
    if (idPedido !== aulaGerenciada) return; // outra aula foi aberta enquanto carregava
    if (!aula) {
      dialogoGerenciar.close();
      return;
    }

    const dados = dadosDaAula(aula);

    // Apenas uma mensagem aparece na parte "Adicionar aluno"
    const aberta = !aula.cancelada && !dados.passou;
    dados.bloqueioCancelada = aula.cancelada;
    dados.bloqueioPassou = !aula.cancelada && dados.passou;
    dados.bloqueioLotada = aberta && dados.lotada;
    dados.bloqueioSemAlunos = aberta && !dados.lotada && disponiveis.length === 0;
    dados.podeAdicionar = aberta && !dados.lotada && disponiveis.length > 0;

    listaInscritos.replaceChildren(); // limpa antes de preencher a janela
    preencher(areaGerenciar, dados);

    preencherLista(listaInscritos, 'modelo-inscrito',
      inscritos.map((aluno) => ({ ...aluno, inicial: aluno.username.charAt(0) })), null,
      (item, aluno) => {
        const botao = item.querySelector('[data-acao="remover"]');
        botao.dataset.alunoId = aluno.id;
        botao.dataset.nome = aluno.username;
      });

    selectAluno.replaceChildren(
      new Option('Selecione um aluno…', ''),
      ...disponiveis.map((aluno) => new Option(aluno.username, aluno.id)),
    );
  }

  async function abrirGerenciar(aulaId) {
    aulaGerenciada = aulaId;
    try {
      await mostrarGerenciar();
    } catch (erro) {
      notificarErro(erro);
      return;
    }
    if (aulaGerenciada === aulaId && !dialogoGerenciar.open) dialogoGerenciar.showModal();
  }

  function aoClicarGerenciar(evento) {
    const botao = evento.target.closest('[data-acao="gerenciar"]');
    if (botao) abrirGerenciar(Number(botao.dataset.aulaId));
  }

  listaProximas.addEventListener('click', aoClicarGerenciar);
  listaAnteriores.addEventListener('click', aoClicarGerenciar);

  document.getElementById('botao-editar').addEventListener('click', () => {
    dialogoGerenciar.close();
    abrirFormularioAula(aulaGerenciada);
  });

  document.getElementById('botao-cancelar-aula').addEventListener('click', async (evento) => {
    const botao = evento.currentTarget;
    try {
      const aula = await Dados.buscarAula(aulaGerenciada);
      if (!aula) throw new ErroRegra('Aula não encontrada.');
      if (!aula.cancelada) {
        const ok = await confirmar(
          'Cancelar esta aula? Ela continuará aparecendo para os alunos inscritos, marcada como cancelada.',
          'Cancelar aula',
        );
        if (!ok) return;
      }
      const cancelada = await comBotaoOcupado(botao, () => Dados.alternarCancelamento(aula.id));
      notificar(cancelada ? 'Aula cancelada.' : 'Aula reativada.');
    } catch (erro) {
      notificarErro(erro);
    }
    await atualizarTudo();
  });

  document.getElementById('botao-excluir-aula').addEventListener('click', async (evento) => {
    const botao = evento.currentTarget;
    const ok = await confirmar(
      'Excluir esta aula definitivamente? As inscrições dela também serão apagadas.',
      'Excluir aula',
    );
    if (!ok) return;
    try {
      await comBotaoOcupado(botao, () => Dados.excluirAula(aulaGerenciada));
      dialogoGerenciar.close();
      notificar('Aula excluída.');
    } catch (erro) {
      notificarErro(erro);
    }
    await atualizarTudo();
  });

  listaInscritos.addEventListener('click', async (evento) => {
    const botao = evento.target.closest('[data-acao="remover"]');
    if (!botao) return;
    const ok = await confirmar(`Remover ${botao.dataset.nome} desta aula?`, 'Remover');
    if (!ok) return;
    try {
      await Dados.removerInscricao(aulaGerenciada, botao.dataset.alunoId);
      notificar('Aluno removido da aula.');
    } catch (erro) {
      notificarErro(erro);
    }
    await atualizarTudo();
  });

  formAdicionar.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    if (!selectAluno.value) {
      notificar('Selecione um aluno para adicionar.', 'erro');
      selectAluno.focus();
      return;
    }
    try {
      await comBotaoOcupado(formAdicionar.querySelector('button[type="submit"]'),
        () => Dados.inscrever(aulaGerenciada, selectAluno.value));
      notificar('Aluno adicionado à aula.');
    } catch (erro) {
      notificarErro(erro);
    }
    await atualizarTudo();
  });

  // ===================================================== SEÇÃO: ALUNOS

  formAluno.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    limparErrosDoFormulario(formAluno);
    const { username, senha } = lerFormulario(formAluno);
    try {
      const aluno = await comBotaoOcupado(formAluno.querySelector('button[type="submit"]'),
        () => Dados.criarUsuario(username, senha, 'aluno'));
      formAluno.reset();
      formAluno.username.focus();
      notificar(`Aluno “${aluno.username}” cadastrado.`);
    } catch (erro) {
      mostrarErrosNoFormulario(formAluno, erro);
    }
    await atualizarTudo();
  });

  listaAlunos.addEventListener('click', async (evento) => {
    const botaoAtivacao = evento.target.closest('[data-acao="ativacao"]');
    if (botaoAtivacao) {
      const ativo = botaoAtivacao.dataset.ativo === 'true';
      if (ativo) {
        const ok = await confirmar(
          `Desativar a conta de ${botaoAtivacao.dataset.nome}? O aluno não conseguirá mais entrar `
          + 'nem se inscrever até a conta ser reativada.',
          'Desativar conta',
        );
        if (!ok) return;
      }
      try {
        await comBotaoOcupado(botaoAtivacao, () => Dados.definirContaAtiva(botaoAtivacao.dataset.alunoId, !ativo));
        notificar(ativo ? 'Conta de aluno desativada.' : 'Conta de aluno reativada.');
      } catch (erro) {
        notificarErro(erro);
      }
      await atualizarTudo();
      return;
    }

    const botao = evento.target.closest('[data-acao="excluir"]');
    if (!botao) return;
    const ok = await confirmar(
      `Excluir a conta de ${botao.dataset.nome}? As inscrições deste aluno também serão removidas.`,
      'Excluir conta',
    );
    if (!ok) return;
    try {
      await comBotaoOcupado(botao, () => Dados.excluirAluno(botao.dataset.alunoId));
      notificar('Conta de aluno excluída.');
    } catch (erro) {
      notificarErro(erro);
    }
    await atualizarTudo();
  });

  // ============================================================= INÍCIO

  ligarTopo(usuario);
  ligarDialogos();
  ligarSecoes('aulas');
  // Se algo mudar em outro aparelho (ex.: um aluno se inscreveu), a tela se atualiza.
  aoMudarDadosEmOutroDispositivo(async () => {
    let atual = null;
    try {
      atual = await Sessao.usuario();
    } catch (erro) {
      return; // sem conexão no momento: tenta de novo na próxima vez
    }
    if (!atual) {
      window.location.replace('login.html');
      return;
    }
    await atualizarTudo();
  });

  await atualizarTudo();
})();
