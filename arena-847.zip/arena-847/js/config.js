/* ==========================================================================
   config.js — Conexão com o Supabase
   --------------------------------------------------------------------------
   Preencha os dois primeiros valores com os dados do SEU projeto Supabase
   (Painel do projeto → Project Settings → API Keys / Data API). Veja o README.

   IMPORTANTE: aqui vai SOMENTE a chave PÚBLICA ("anon" ou "publishable",
   que começa com "sb_publishable_..." ou é um JWT com role "anon").
   NUNCA coloque a chave "service_role" / "secret" neste arquivo: ele é
   enviado para o navegador de qualquer visitante.
   ========================================================================== */

const CONFIG_SUPABASE = {
  // Ex.: 'https://abcdefghijklmnop.supabase.co'
  url: 'https://ogplzrwdwgcnrxzwasqg.supabase.co',

  // Ex.: 'sb_publishable_...'  (ou a chave "anon public" antiga, que começa com "eyJ...")
  chavePublica: 'sb_publishable_HdvT3w-rsTiP_90iHBWuhA_6n81uMDo',

  // O Supabase Auth identifica cada conta por um e-mail. Para manter o login
  // só com nome de usuário, o sistema monta internamente um endereço
  // "nomedeusuario@dominioLogin". Nenhum e-mail é enviado para ele.
  // Só altere ANTES de criar as contas (veja o README).
  dominioLogin: 'usuarios.arena847.app',

  // Fuso horário da arena: o banco usa America/Sao_Paulo (veja banco.sql).
};
