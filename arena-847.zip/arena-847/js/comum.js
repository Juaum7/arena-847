/* ==========================================================================
   comum.js — Funções usadas pelas páginas de login, aluno e administrador
   --------------------------------------------------------------------------
   A estrutura das páginas está toda no HTML. Este arquivo só ajuda o
   JavaScript a preencher o HTML com os dados, mostrar mensagens, controlar
   a sessão de login, o menu do celular e as janelas de confirmação.

   Atributos usados no HTML para receber os dados (função "preencher"):
     data-campo="nome"          recebe o texto de dados.nome
     data-se="nome"             aparece somente se dados.nome for verdadeiro
     data-se-nao="nome"         aparece somente se dados.nome for falso
     data-classe="classe:nome"  recebe a classe CSS se dados.nome for verdadeiro
     data-atributos="max:nome"  recebe atributos (vários separados por ";")
   ========================================================================== */

// ------------------------------------------------------------------ sessão
// A sessão de login é controlada pelo Supabase Auth (veja dados.js): ela
// continua valendo ao atualizar a página ou ao voltar ao site depois.

const Sessao = {
  /** O Supabase Auth já guarda a sessão no login; mantido por compatibilidade. */
  entrar() {},

  async sair() {
    await Dados.sair();
  },

  /** Usuário logado (ou null). Contas desativadas têm a sessão encerrada. */
  async usuario() {
    return Dados.usuarioLogado();
  },

  paginaInicial(usuario) {
    return usuario.papel === 'admin' ? 'administrador.html' : 'aluno.html';
  },

  /**
   * Garante que quem está na página tem o papel certo.
   * Sem login: vai para o login. Papel errado: vai para a sua própria área.
   */
  async exigir(papel) {
    let usuario = null;
    try {
      usuario = await this.usuario();
    } catch (erro) {
      console.error(erro);
    }
    if (!usuario) {
      window.location.replace('login.html');
      return null;
    }
    if (usuario.papel !== papel) {
      window.location.replace(this.paginaInicial(usuario));
      return null;
    }
    // Se a sessão for encerrada (ex.: "Sair" em outra aba), volta para o login.
    Dados.aoEncerrarSessao(() => window.location.replace('login.html'));
    return usuario;
  },
};

// ------------------------------------------------- preencher o HTML

function elementosCom(raiz, atributo) {
  const lista = Array.from(raiz.querySelectorAll(`[${atributo}]`));
  if (raiz.hasAttribute && raiz.hasAttribute(atributo)) lista.unshift(raiz);
  return lista;
}

function lerPares(texto) {
  return texto.split(';').map((par) => par.split(':').map((parte) => parte.trim()));
}

/** Preenche um trecho do HTML com os dados (veja os atributos no topo). */
function preencher(raiz, dados) {
  elementosCom(raiz, 'data-campo').forEach((el) => {
    const valor = dados[el.dataset.campo];
    el.textContent = valor === undefined || valor === null ? '' : valor;
  });
  elementosCom(raiz, 'data-se').forEach((el) => { el.hidden = !dados[el.dataset.se]; });
  elementosCom(raiz, 'data-se-nao').forEach((el) => { el.hidden = Boolean(dados[el.dataset.seNao]); });
  elementosCom(raiz, 'data-classe').forEach((el) => {
    lerPares(el.dataset.classe).forEach(([classe, campo]) => el.classList.toggle(classe, Boolean(dados[campo])));
  });
  elementosCom(raiz, 'data-atributos').forEach((el) => {
    lerPares(el.dataset.atributos).forEach(([atributo, campo]) => {
      if (dados[campo] !== undefined) el.setAttribute(atributo, dados[campo]);
    });
  });
}

/** Faz uma cópia de um <template> da página e a preenche com os dados. */
function copiarModelo(idModelo, dados) {
  const modelo = document.getElementById(idModelo);
  const elemento = modelo.content.firstElementChild.cloneNode(true);
  preencher(elemento, dados);
  return elemento;
}

/**
 * Preenche uma lista com uma cópia do modelo para cada item.
 * "aoCriar" permite ligar cada elemento ao seu item (ex.: guardar o id no botão).
 * Mostra o elemento de "lista vazia" quando não houver itens.
 */
function preencherLista(lista, idModelo, itens, elementoVazio, aoCriar) {
  const elementos = itens.map((item) => {
    const elemento = copiarModelo(idModelo, item);
    if (aoCriar) aoCriar(elemento, item);
    return elemento;
  });
  lista.replaceChildren(...elementos);
  lista.hidden = itens.length === 0;
  if (elementoVazio) elementoVazio.hidden = itens.length > 0;
}

// --------------------------------------------- dados para exibição

const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
const DIAS_SEMANA = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];

/** Prepara os dados de uma aula para preencher os cartões do HTML. */
function dadosDaAula(aula) {
  const [ano, mes, dia] = aula.data.split('-').map(Number);
  const livres = aula.maxAlunos - aula.inscritos;
  const passou = Dados.aulaJaPassou(aula);
  return {
    ...aula,
    ehFutevolei: aula.modalidade === 'Futevôlei',
    diaNumero: String(dia).padStart(2, '0'),
    mes: MESES[mes - 1],
    diaSemana: DIAS_SEMANA[new Date(ano, mes - 1, dia).getDay()],
    dataCompleta: `${String(dia).padStart(2, '0')}/${String(mes).padStart(2, '0')}/${ano}`,
    livres,
    temVagas: livres > 0,
    lotada: livres <= 0,
    textoVagas: livres === 1 ? '1 vaga disponível' : `${livres} vagas disponíveis`,
    ocupacao: `${aula.inscritos}/${aula.maxAlunos}`,
    passou,
    realizada: passou && !aula.cancelada,
  };
}

// ---------------------------------------------- mensagens (avisos)

/** Mostra uma mensagem rápida no canto da tela. Tipos: "sucesso" ou "erro". */
function notificar(mensagem, tipo = 'sucesso') {
  const area = document.getElementById('notificacoes');
  const aviso = document.createElement('div');
  aviso.className = `notificacao notificacao--${tipo}`;
  aviso.setAttribute('role', tipo === 'erro' ? 'alert' : 'status');
  aviso.textContent = mensagem;
  area.append(aviso);

  // Mantém no máximo 3 mensagens na tela
  while (area.children.length > 3) area.firstElementChild.remove();

  // A área de mensagens é um "popover": assim ela aparece na frente
  // até das janelas abertas (dialog). Reabrir a coloca por cima de tudo.
  if (typeof area.showPopover === 'function') {
    if (area.matches(':popover-open')) area.hidePopover();
    area.showPopover();
  }

  const duracao = tipo === 'erro' ? 5500 : 3500;
  setTimeout(() => aviso.classList.add('notificacao--saindo'), duracao);
  setTimeout(() => {
    aviso.remove();
    if (!area.children.length && typeof area.hidePopover === 'function' && area.matches(':popover-open')) {
      area.hidePopover();
    }
  }, duracao + 500);
}

/** Mostra o erro de uma ação para o usuário. */
function notificarErro(erro) {
  if (erro instanceof ErroRegra) {
    erro.mensagens.forEach((mensagem) => notificar(mensagem, 'erro'));
  } else {
    console.error(erro);
    notificar('Algo deu errado. Tente novamente.', 'erro');
  }
}

/** Mostra mensagens de erro dentro de um formulário (elemento com data-erros). */
function mostrarErrosNoFormulario(form, erro) {
  const area = form.querySelector('[data-erros]');
  if (!area) return notificarErro(erro);
  const mensagens = erro instanceof ErroRegra ? erro.mensagens : ['Algo deu errado. Tente novamente.'];
  area.textContent = mensagens.join(' ');
  area.hidden = false;
}

function limparErrosDoFormulario(form) {
  const area = form.querySelector('[data-erros]');
  if (area) {
    area.textContent = '';
    area.hidden = true;
  }
}

// ------------------------------------------------- janelas (dialog)

/** Abre a janela de confirmação da página e devolve true se a pessoa confirmar. */
function confirmar(mensagem, textoBotao = 'Confirmar') {
  const dialogo = document.getElementById('dialogo-confirmacao');
  dialogo.querySelector('[data-mensagem]').textContent = mensagem;
  dialogo.querySelector('[data-confirmar]').textContent = textoBotao;
  dialogo.returnValue = '';
  dialogo.showModal();
  return new Promise((resolver) => {
    dialogo.addEventListener('close', () => resolver(dialogo.returnValue === 'sim'), { once: true });
  });
}

/** Faz os botões [data-fechar] e o clique fora da janela fecharem os dialogs. */
function ligarDialogos() {
  document.querySelectorAll('dialog').forEach((dialogo) => {
    dialogo.addEventListener('click', (evento) => {
      if (evento.target === dialogo) dialogo.close();
      if (evento.target.closest('[data-fechar]')) dialogo.close();
    });
  });
}

// ---------------------------------------------------- topo da página

/** Menu do celular (botão ☰) e botão "Sair". */
function ligarTopo(usuario) {
  const botaoMenu = document.getElementById('menu-botao');
  const menu = document.getElementById('menu');

  if (botaoMenu && menu) {
    const fechar = () => {
      menu.classList.remove('menu--aberto');
      botaoMenu.setAttribute('aria-expanded', 'false');
    };
    botaoMenu.addEventListener('click', () => {
      const aberto = menu.classList.toggle('menu--aberto');
      botaoMenu.setAttribute('aria-expanded', String(aberto));
    });
    menu.addEventListener('click', (evento) => {
      if (evento.target.closest('a')) fechar();
    });
    document.addEventListener('keydown', (evento) => {
      if (evento.key === 'Escape') fechar();
    });
  }

  if (usuario) {
    document.querySelectorAll('[data-usuario]').forEach((el) => { el.textContent = usuario.username; });
  }

  const botaoSair = document.getElementById('botao-sair');
  if (botaoSair) {
    botaoSair.addEventListener('click', async () => {
      botaoSair.disabled = true;
      try {
        await Sessao.sair();
      } catch (erro) {
        console.error(erro);
      }
      window.location.href = 'login.html';
    });
  }
}

/**
 * Alterna entre as seções da página (ex.: #aulas e #alunos) usando o
 * endereço da página. Os links do menu têm data-secao; as seções têm data-secao-conteudo.
 */
function ligarSecoes(secaoPadrao, aoMostrar) {
  const secoes = Array.from(document.querySelectorAll('[data-secao-conteudo]'));
  const nomes = secoes.map((s) => s.dataset.secaoConteudo);

  function mostrar() {
    const pedida = window.location.hash.slice(1);
    const atual = nomes.includes(pedida) ? pedida : secaoPadrao;
    secoes.forEach((secao) => { secao.hidden = secao.dataset.secaoConteudo !== atual; });
    document.querySelectorAll('[data-secao]').forEach((link) => {
      const ativo = link.dataset.secao === atual;
      link.classList.toggle('ativo', ativo);
      if (ativo) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    if (aoMostrar) aoMostrar(atual);
  }

  window.addEventListener('hashchange', () => {
    mostrar();
    window.scrollTo({ top: 0 });
  });
  mostrar();
}

/**
 * Executa "aoMudar" quando os dados forem alterados em outro aparelho ou aba:
 * - na hora, pelo tempo real do Supabase (aulas e inscrições);
 * - quando a pessoa volta para a página (troca de aba ou de aplicativo);
 * - e a cada 30 segundos, como garantia (ex.: vagas ocupadas por outros alunos).
 */
function aoMudarDadosEmOutroDispositivo(aoMudar) {
  Dados.aoMudarNoBanco(aoMudar);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') aoMudar();
  });
  setInterval(() => {
    if (document.visibilityState === 'visible') aoMudar();
  }, 30000);
}

/**
 * Evita que duas atualizações da tela rodem ao mesmo tempo: se uma nova for
 * pedida durante outra, ela roda logo em seguida (uma única vez).
 */
function semSobreposicao(funcao) {
  let rodando = null;
  let pendente = false;
  return async function executar() {
    if (rodando) {
      pendente = true;
      return rodando;
    }
    rodando = (async () => {
      do {
        pendente = false;
        await funcao();
      } while (pendente);
    })();
    try {
      await rodando;
    } finally {
      rodando = null;
    }
  };
}

/** Lê os campos de um formulário como objeto. */
function lerFormulario(form) {
  return Object.fromEntries(new FormData(form));
}
