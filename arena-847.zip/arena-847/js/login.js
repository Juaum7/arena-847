/* ==========================================================================
   login.js — Página de login
   - Se a pessoa já estiver logada, vai direto para a sua área.
   - O login é feito no Supabase Auth, com nome de usuário e senha.
   - Não existe mais criação pública de administrador: o primeiro
     administrador é criado por um procedimento controlado (veja o README).
   ========================================================================== */

(async function () {
  const formLogin = document.getElementById('form-login');
  const botaoEntrar = formLogin.querySelector('button[type="submit"]');

  // Botão "Mostrar/Ocultar" senha
  document.querySelectorAll('[data-mostrar-senha]').forEach((botao) => {
    botao.addEventListener('click', () => {
      const campo = botao.previousElementSibling;
      const mostrar = campo.type === 'password';
      campo.type = mostrar ? 'text' : 'password';
      botao.textContent = mostrar ? 'Ocultar' : 'Mostrar';
      botao.setAttribute('aria-label', mostrar ? 'Ocultar senha' : 'Mostrar senha');
    });
  });

  // Login
  formLogin.addEventListener('submit', async (evento) => {
    evento.preventDefault();
    limparErrosDoFormulario(formLogin);
    const { username, senha } = lerFormulario(formLogin);

    if (!username.trim() || !senha) {
      mostrarErrosNoFormulario(formLogin, new ErroRegra('Preencha o nome de usuário e a senha.'));
      return;
    }

    botaoEntrar.disabled = true;
    try {
      const usuario = await Dados.autenticar(username, senha);
      if (!usuario) {
        mostrarErrosNoFormulario(formLogin, new ErroRegra('Usuário ou senha incorretos.'));
        formLogin.senha.value = '';
        formLogin.senha.focus();
        return;
      }
      Sessao.entrar(usuario);
      window.location.href = Sessao.paginaInicial(usuario);
    } catch (erro) {
      mostrarErrosNoFormulario(formLogin, erro);
    } finally {
      botaoEntrar.disabled = false;
    }
  });

  formLogin.querySelector('input').focus();

  // Já está logado neste aparelho? Vai direto para a sua área.
  try {
    const usuarioLogado = await Sessao.usuario();
    if (usuarioLogado) {
      window.location.replace(Sessao.paginaInicial(usuarioLogado));
      return;
    }
  } catch (erro) {
    console.error(erro);
  }

  // Avisos de configuração (só aparecem enquanto o sistema não estiver pronto).
  try {
    if (!(await Dados.existeAdmin())) {
      mostrarErrosNoFormulario(formLogin, new ErroRegra(
        'O sistema ainda não tem um administrador. Siga o passo “Criar o primeiro administrador” do README.',
      ));
    }
  } catch (erro) {
    mostrarErrosNoFormulario(formLogin, erro);
  }
})();
