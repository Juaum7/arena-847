/* ==========================================================================
   aluno.js — Área do aluno
   Lista as aulas disponíveis, faz a inscrição, mostra "Minhas aulas" e
   permite cancelar a própria inscrição em aulas que ainda não aconteceram.
   O HTML dos cartões está nos <template> do aluno.html.
   ========================================================================== */

(async function () {
  const usuario = await Sessao.exigir('aluno');
  if (!usuario) return;

  const listaAulas = document.getElementById('lista-aulas');
  const listaMinhas = document.getElementById('lista-minhas');
  const listaAnteriores = document.getElementById('lista-anteriores');

  // ------------------------------------------------------------ exibição

  async function mostrarAulasDisponiveis() {
    const aulas = await Dados.listarAulas({ futuras: true, somenteAtivas: true, alunoId: usuario.id });
    const itens = aulas.map((aula) => {
      const dados = dadosDaAula(aula);
      dados.podeInscrever = !aula.inscrito && dados.temVagas;
      dados.lotadaSemInscricao = !aula.inscrito && dados.lotada;
      return dados;
    });

    preencherLista(listaAulas, 'modelo-aula', itens, document.getElementById('sem-aulas'),
      (cartao, aula) => {
        const botao = cartao.querySelector('[data-acao="inscrever"]');
        botao.dataset.aulaId = aula.id;
      });
  }

  function dadosMinhaAula(aula) {
    const dados = dadosDaAula(aula);
    dados.confirmada = !aula.cancelada && !dados.passou;
    dados.apagado = aula.cancelada || dados.passou;
    return dados;
  }

  function ligarBotaoCancelar(cartao, aula) {
    const botao = cartao.querySelector('[data-acao="cancelar-inscricao"]');
    if (botao) botao.dataset.aulaId = aula.id;
  }

  async function mostrarMinhasAulas() {
    const [proximas, anteriores] = await Promise.all([
      Dados.listarAulas({ futuras: true, alunoId: usuario.id, apenasInscritas: true }),
      Dados.listarAulas({ futuras: false, alunoId: usuario.id, apenasInscritas: true }),
    ]);

    preencherLista(listaMinhas, 'modelo-minha-aula', proximas.map(dadosMinhaAula),
      document.getElementById('sem-minhas'), ligarBotaoCancelar);

    document.getElementById('bloco-anteriores').hidden = anteriores.length === 0;
    document.getElementById('contador-anteriores').textContent = anteriores.length;
    preencherLista(listaAnteriores, 'modelo-minha-aula', anteriores.map(dadosMinhaAula));

    const ativas = proximas.filter((a) => !a.cancelada).length;
    document.getElementById('contador-minhas').textContent = ativas;
  }

  const atualizarTudo = semSobreposicao(async () => {
    try {
      await Promise.all([mostrarAulasDisponiveis(), mostrarMinhasAulas()]);
    } catch (erro) {
      notificarErro(erro);
    }
  });

  // --------------------------------------------------------------- ações

  listaAulas.addEventListener('click', async (evento) => {
    const botao = evento.target.closest('[data-acao="inscrever"]');
    if (!botao || botao.disabled) return;

    botao.disabled = true;
    try {
      await Dados.inscrever(Number(botao.dataset.aulaId), usuario.id);
      notificar('Inscrição realizada! A aula já está em “Minhas aulas”.');
    } catch (erro) {
      if (erro instanceof ErroRegra && erro.message.includes('já está inscrito')) {
        notificar('Você já está inscrito nesta aula.', 'erro');
      } else {
        notificarErro(erro);
      }
    }
    await atualizarTudo();
  });

  listaMinhas.addEventListener('click', async (evento) => {
    const botao = evento.target.closest('[data-acao="cancelar-inscricao"]');
    if (!botao || botao.disabled) return;
    const ok = await confirmar('Cancelar sua inscrição nesta aula? A vaga ficará livre para outros alunos.',
      'Cancelar inscrição');
    if (!ok) return;

    botao.disabled = true;
    try {
      await Dados.removerInscricao(Number(botao.dataset.aulaId), usuario.id);
      notificar('Inscrição cancelada.');
    } catch (erro) {
      notificarErro(erro);
    }
    await atualizarTudo();
  });

  // ------------------------------------------------------------- início

  ligarTopo(usuario);
  ligarDialogos();
  ligarSecoes('aulas');
  // Se o administrador ou outro aluno alterar algo (em qualquer aparelho),
  // a tela se atualiza sozinha. Se a conta for desativada, volta ao login.
  aoMudarDadosEmOutroDispositivo(async () => {
    let atual = null;
    try {
      atual = await Sessao.usuario();
    } catch (erro) {
      return; // sem conexão no momento: tenta de novo na próxima vez
    }
    if (!atual) {
      window.location.replace('login.html');
      return;
    }
    await atualizarTudo();
  });

  await atualizarTudo();
})();
