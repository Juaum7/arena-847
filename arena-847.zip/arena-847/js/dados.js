/* ==========================================================================
   dados.js — Armazenamento e regras do sistema
   --------------------------------------------------------------------------
   Os dados (usuários, aulas e inscrições) ficam no banco de dados online
   (Supabase), compartilhado por todos os aparelhos. As regras são conferidas
   aqui (para mostrar a mensagem certa rapidamente) e, principalmente, dentro
   do próprio banco (arquivo supabase/banco.sql), onde não podem ser burladas:
     - o limite de vagas de cada aula nunca é ultrapassado (operação atômica);
     - um aluno não pode se inscrever duas vezes na mesma aula;
     - não é possível se inscrever em aula cancelada ou que já aconteceu;
     - contas desativadas não acessam nada.

   Todas as funções que falam com o banco são assíncronas: use "await".
   ========================================================================== */

const MODALIDADES = ['Vôlei', 'Futevôlei'];
const LIMITE_ALUNOS_POR_AULA = 100;
const TAMANHO_MINIMO_SENHA = 6;
const PADRAO_USUARIO = /^[A-Za-z0-9._-]{3,30}$/;

/** Erro de regra do sistema: as mensagens são mostradas para o usuário. */
class ErroRegra extends Error {
  constructor(mensagens) {
    const lista = [].concat(mensagens);
    super(lista[0]);
    this.mensagens = lista;
  }
}

const Dados = (function () {
  // ------------------------------------------------------------ conexão

  const configurado = typeof CONFIG_SUPABASE !== 'undefined'
    && /^https:\/\//.test(CONFIG_SUPABASE.url)
    && CONFIG_SUPABASE.chavePublica
    && !CONFIG_SUPABASE.chavePublica.startsWith('COLE_AQUI');

  const ERRO_CONFIGURACAO = new ErroRegra(
    'O sistema ainda não está conectado ao banco de dados. '
    + 'Preencha a URL e a chave pública do Supabase em js/config.js (veja o README).',
  );

  function criarCliente(opcoesAuth) {
    if (!configurado) return null;
    if (!window.supabase || typeof window.supabase.createClient !== 'function') {
      console.error('Biblioteca do Supabase não carregou (verifique a internet).');
      return null;
    }
    return window.supabase.createClient(CONFIG_SUPABASE.url, CONFIG_SUPABASE.chavePublica, { auth: opcoesAuth });
  }

  // Cliente principal: a sessão de login é guardada pelo próprio Supabase Auth
  // (com renovação automática), e continua valendo ao atualizar a página.
  const supa = criarCliente({ persistSession: true, autoRefreshToken: true, storageKey: 'arena847.auth' });

  function cliente() {
    if (!supa) {
      if (configurado) {
        throw new ErroRegra('Não foi possível carregar a conexão com o banco de dados. '
          + 'Verifique a internet e atualize a página.');
      }
      throw ERRO_CONFIGURACAO;
    }
    return supa;
  }

  /** Transforma erros do Supabase em mensagens para o usuário. */
  function converterErro(erro) {
    if (!erro) return null;
    if (erro instanceof ErroRegra) return erro;
    const msg = String(erro.message || '');
    // Mensagens das regras escritas em banco.sql ("raise exception")
    if (erro.code === 'P0001' && msg) return new ErroRegra(msg);
    if (erro.code === '23505') return new ErroRegra('Este registro já existe.');
    if (erro.code === '42501' || /row-level security|permission denied/i.test(msg)) {
      return new ErroRegra('Você não tem permissão para fazer isso.');
    }
    if (erro.code === 'PGRST301' || /JWT|refresh token/i.test(msg)) {
      return new ErroRegra('Sua sessão expirou. Entre novamente.');
    }
    if (/fetch|network|Load failed/i.test(msg)) {
      return new ErroRegra('Sem conexão com o servidor. Verifique a internet e tente novamente.');
    }
    if (erro.code === 'PGRST202' || erro.code === '42P01' || erro.code === '42883') {
      return new ErroRegra('O banco de dados não está configurado. Execute o arquivo supabase/banco.sql (veja o README).');
    }
    const generico = new Error(msg || 'Erro desconhecido');
    generico.original = erro;
    return generico;
  }

  /** Executa uma consulta do Supabase e devolve os dados (ou lança o erro). */
  async function executar(consulta) {
    let resposta;
    try {
      resposta = await consulta;
    } catch (erro) {
      throw converterErro(erro);
    }
    if (resposta.error) throw converterErro(resposta.error);
    return resposta;
  }

  async function obter(consulta) {
    return (await executar(consulta)).data;
  }

  // -------------------------------------------------------- data e hora

  const doisDigitos = (n) => String(n).padStart(2, '0');

  /** Data e hora atuais no formato "AAAA-MM-DD HH:MM" (fácil de comparar). */
  function agoraTexto() {
    const d = new Date();
    return `${d.getFullYear()}-${doisDigitos(d.getMonth() + 1)}-${doisDigitos(d.getDate())} `
      + `${doisDigitos(d.getHours())}:${doisDigitos(d.getMinutes())}`;
  }

  function hojeTexto() {
    return agoraTexto().slice(0, 10);
  }

  function aulaJaPassou(aula) {
    return `${aula.data} ${aula.horario}` <= agoraTexto();
  }

  function dataValida(texto) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(texto)) return false;
    const [a, m, d] = texto.split('-').map(Number);
    const data = new Date(a, m - 1, d);
    return data.getFullYear() === a && data.getMonth() === m - 1 && data.getDate() === d;
  }

  function horarioValido(texto) {
    return /^([01]\d|2[0-3]):[0-5]\d$/.test(texto);
  }

  // ---------------------------------------------------------- auxiliares

  /** Endereço interno usado no Supabase Auth para um nome de usuário. */
  const emailDoUsuario = (username) =>
    `${String(username || '').trim().toLowerCase()}@${CONFIG_SUPABASE.dominioLogin}`;

  const porNome = (a, b) => a.username.localeCompare(b.username, 'pt-BR', { sensitivity: 'base' });

  const paraUsuario = (linha) => ({
    id: linha.id,
    username: linha.username,
    papel: linha.papel,
    ativo: linha.situacao === 'ativa',
  });

  /** Linha do banco (snake_case) → objeto de aula usado pelas telas. */
  const paraAula = (linha) => ({
    id: Number(linha.id),
    modalidade: linha.modalidade,
    data: linha.data,
    horario: String(linha.horario).slice(0, 5),
    maxAlunos: linha.max_alunos,
    cancelada: linha.situacao === 'cancelada',
    inscritos: Number(linha.inscritos || 0),
    inscrito: Boolean(linha.inscrito),
  });

  function validarAula(campos, { inscritosAtuais = 0, exigirDataFutura = true } = {}) {
    const erros = [];
    const modalidade = String(campos.modalidade || '');
    const data = String(campos.data || '').trim();
    const horario = String(campos.horario || '').trim();
    const maxAlunos = Number(campos.maxAlunos);

    if (!MODALIDADES.includes(modalidade)) erros.push('Escolha a modalidade da aula.');

    if (!dataValida(data) || !horarioValido(horario)) {
      erros.push('Informe uma data e um horário válidos.');
    } else if (exigirDataFutura && `${data} ${horario}` <= agoraTexto()) {
      erros.push('A data e o horário da aula precisam estar no futuro.');
    }

    if (!Number.isInteger(maxAlunos)) {
      erros.push('Informe a quantidade máxima de alunos.');
    } else if (maxAlunos < 1 || maxAlunos > LIMITE_ALUNOS_POR_AULA) {
      erros.push(`A quantidade de vagas deve ficar entre 1 e ${LIMITE_ALUNOS_POR_AULA}.`);
    } else if (maxAlunos < inscritosAtuais) {
      erros.push(`Esta aula já tem ${inscritosAtuais} aluno(s) inscrito(s). `
        + 'Remova alunos antes de reduzir as vagas para menos que isso.');
    }

    if (erros.length) throw new ErroRegra(erros);
    return { modalidade, data, horario, maxAlunos };
  }

  async function buscarPerfil(id) {
    const linha = await obter(cliente().from('perfis').select('id, username, papel, situacao').eq('id', id).maybeSingle());
    return linha ? paraUsuario(linha) : null;
  }

  async function buscarAulaOuErro(aulaId) {
    const aula = await api.buscarAula(aulaId);
    if (!aula) throw new ErroRegra('Aula não encontrada.');
    return aula;
  }

  // ===================================================== API pública

  const api = {
    MODALIDADES,
    hojeTexto,
    aulaJaPassou,
    configurado,

    // ------------------------------------------------------------ sessão

    /**
     * Usuário logado neste aparelho (ou null).
     * Se a conta tiver sido desativada (ou não tiver perfil), encerra a sessão.
     */
    async usuarioLogado() {
      if (!supa) return null;
      const { data } = await supa.auth.getSession();
      if (!data || !data.session) return null;
      let perfil;
      try {
        perfil = await buscarPerfil(data.session.user.id);
      } catch (erro) {
        if (erro instanceof ErroRegra && /sessão expirou/.test(erro.message)) {
          await supa.auth.signOut({ scope: 'local' });
          return null;
        }
        throw erro;
      }
      if (!perfil || !perfil.ativo) {
        await supa.auth.signOut({ scope: 'local' });
        return null;
      }
      return perfil;
    },

    async sair() {
      if (supa) await supa.auth.signOut({ scope: 'local' });
    },

    /** Executa "aoSair" se a sessão for encerrada (ex.: logout em outra aba). */
    aoEncerrarSessao(aoSair) {
      if (!supa) return;
      supa.auth.onAuthStateChange((evento) => {
        if (evento === 'SIGNED_OUT') aoSair();
      });
    },

    /**
     * Avisa quando aulas ou inscrições mudarem em qualquer aparelho
     * (tempo real do Supabase). Várias mudanças seguidas geram um só aviso.
     */
    aoMudarNoBanco(aoMudar) {
      if (!supa) return;
      let espera = null;
      const avisar = () => {
        clearTimeout(espera);
        espera = setTimeout(aoMudar, 400);
      };
      supa.channel('arena847-mudancas')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'aulas' }, avisar)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'inscricoes' }, avisar)
        .subscribe();
    },

    // ----------------------------------------------------------- usuários

    async existeAdmin() {
      return obter(cliente().rpc('existe_admin'));
    },

    async buscarUsuario(id) {
      return buscarPerfil(id);
    },

    /**
     * Cria a conta de um aluno (somente o administrador).
     * 1) o banco gera um convite de uso único (só o admin consegue);
     * 2) a conta é criada no Supabase Auth com esse convite, em uma conexão
     *    separada, para não trocar a sessão do administrador;
     * 3) o banco cria o perfil do aluno ao receber a conta.
     */
    async criarUsuario(username, senha, papel) {
      const nome = String(username || '').trim();
      const textoSenha = String(senha || '');
      if (!PADRAO_USUARIO.test(nome) || /^\.|\.$|\.\./.test(nome)) {
        throw new ErroRegra('O nome de usuário deve ter de 3 a 30 caracteres, usando letras, números, '
          + 'ponto, hífen ou sublinhado (sem espaços e sem acentos).');
      }
      if (textoSenha.length < TAMANHO_MINIMO_SENHA) {
        throw new ErroRegra(`A senha deve ter pelo menos ${TAMANHO_MINIMO_SENHA} caracteres.`);
      }
      if (papel !== 'aluno') {
        throw new ErroRegra('Contas de administrador são criadas somente pelo procedimento inicial descrito no README.');
      }

      const convite = await obter(cliente().rpc('criar_convite', { p_username: nome }));

      const cadastro = criarCliente({
        persistSession: false, autoRefreshToken: false, detectSessionInUrl: false, storageKey: 'arena847.cadastro',
      });
      let resposta;
      try {
        resposta = await cadastro.auth.signUp({
          email: emailDoUsuario(nome),
          password: textoSenha,
          options: { data: { convite, username: nome } },
        });
      } catch (erro) {
        throw converterErro(erro);
      }

      const { data, error } = resposta;
      if (error) {
        const msg = String(error.message || '');
        if (/already|registered|exists/i.test(msg)) throw new ErroRegra('Já existe um usuário com esse nome.');
        if (/password/i.test(msg)) {
          throw new ErroRegra(`A senha não foi aceita pelo Supabase: ${msg}`);
        }
        if (/email.*invalid|invalid.*email/i.test(msg)) {
          throw new ErroRegra('O Supabase recusou o endereço interno de login. '
            + 'Ajuste "dominioLogin" em js/config.js (veja o README).');
        }
        if (/signups? not allowed|disabled/i.test(msg)) {
          throw new ErroRegra('O cadastro de contas está desligado no Supabase. '
            + 'Ative "Allow new users to sign up" (veja o README).');
        }
        if (/rate limit|too many/i.test(msg) || error.status === 429) {
          throw new ErroRegra('O Supabase limitou a criação de contas por alguns minutos. Aguarde e tente de novo.');
        }
        if (/database error/i.test(msg)) {
          throw new ErroRegra('O banco recusou o cadastro. Tente novamente; se persistir, '
            + 'confira se o arquivo supabase/banco.sql foi executado.');
        }
        throw converterErro(error);
      }
      if (data.user && Array.isArray(data.user.identities) && data.user.identities.length === 0) {
        throw new ErroRegra('Já existe um usuário com esse nome.');
      }
      if (!data.session) {
        throw new ErroRegra('A conta foi criada, mas o Supabase está exigindo confirmação de e-mail, então o aluno '
          + 'ainda não consegue entrar. Desative "Confirm email" no Supabase (veja o README).');
      }
      return { id: data.user.id, username: nome, papel: 'aluno', ativo: true };
    },

    /**
     * Confere usuário e senha no Supabase Auth.
     * Retorna o usuário, null (usuário/senha incorretos) ou lança ErroRegra
     * (conta desativada, sem conexão etc.).
     */
    async autenticar(username, senha) {
      const nome = String(username || '').trim();
      if (!PADRAO_USUARIO.test(nome)) return null;

      let resposta;
      try {
        resposta = await cliente().auth.signInWithPassword({ email: emailDoUsuario(nome), password: String(senha) });
      } catch (erro) {
        throw converterErro(erro);
      }
      const { data, error } = resposta;
      if (error) {
        if (/invalid login|invalid credentials|invalid_credentials/i.test(`${error.message} ${error.code}`)) return null;
        if (/email not confirmed/i.test(error.message)) {
          throw new ErroRegra('Esta conta ainda não foi confirmada no Supabase. Fale com a administração da arena.');
        }
        throw converterErro(error);
      }

      const perfil = await buscarPerfil(data.user.id);
      if (!perfil) {
        await supa.auth.signOut({ scope: 'local' });
        throw new ErroRegra('Esta conta ainda não tem acesso ao sistema. Fale com a administração da arena.');
      }
      if (!perfil.ativo) {
        await supa.auth.signOut({ scope: 'local' });
        throw new ErroRegra('Esta conta está desativada. Fale com a administração da arena.');
      }
      return perfil;
    },

    async listarAlunos() {
      const linhas = await obter(cliente().from('perfis')
        .select('id, username, papel, situacao, inscricoes(count)')
        .eq('papel', 'aluno'));
      return linhas
        .map((linha) => ({
          ...paraUsuario(linha),
          totalInscricoes: Number((linha.inscricoes && linha.inscricoes[0] && linha.inscricoes[0].count) || 0),
        }))
        .sort(porNome);
    },

    async excluirAluno(alunoId) {
      await executar(cliente().rpc('excluir_aluno', { p_aluno_id: alunoId }));
    },

    /** Desativa (ativo = false) ou reativa (ativo = true) a conta de um aluno. */
    async definirContaAtiva(alunoId, ativo) {
      await executar(cliente().rpc('definir_situacao_aluno', {
        p_aluno_id: alunoId,
        p_situacao: ativo ? 'ativa' : 'desativada',
      }));
    },

    // -------------------------------------------------------------- aulas

    /** Lista aulas futuras (ou anteriores) com filtros opcionais. */
    async listarAulas({ futuras = true, somenteAtivas = false, alunoId = null, apenasInscritas = false } = {}) {
      const linhas = await obter(cliente().rpc('aulas_com_vagas'));
      let aulas = linhas
        .map(paraAula)
        .filter((aula) => aulaJaPassou(aula) !== futuras);

      if (somenteAtivas) aulas = aulas.filter((a) => !a.cancelada);
      if (alunoId === null) aulas = aulas.map(({ inscrito, ...resto }) => resto);
      if (apenasInscritas) aulas = aulas.filter((a) => a.inscrito);

      const chave = (a) => `${a.data} ${a.horario}`;
      return aulas.sort((x, y) => (futuras ? 1 : -1) * chave(x).localeCompare(chave(y)));
    },

    async buscarAula(aulaId) {
      const linha = await obter(cliente().rpc('aulas_com_vagas').eq('id', aulaId).maybeSingle());
      return linha ? paraAula(linha) : null;
    },

    async criarAula(campos) {
      const valores = validarAula(campos);
      const linha = await obter(cliente().from('aulas').insert({
        modalidade: valores.modalidade,
        data: valores.data,
        horario: valores.horario,
        max_alunos: valores.maxAlunos,
      }).select('id').single());
      return Number(linha.id);
    },

    async atualizarAula(aulaId, campos) {
      const aula = await buscarAulaOuErro(aulaId);
      const valores = validarAula(campos, { inscritosAtuais: aula.inscritos, exigirDataFutura: false });
      // O banco confere de novo o limite x inscritos no momento da gravação.
      const linhas = await obter(cliente().from('aulas').update({
        modalidade: valores.modalidade,
        data: valores.data,
        horario: valores.horario,
        max_alunos: valores.maxAlunos,
      }).eq('id', aulaId).select('id'));
      if (!linhas.length) throw new ErroRegra('Aula não encontrada.');
    },

    /** Cancela a aula (ou reativa, se já estiver cancelada). Retorna a nova situação. */
    async alternarCancelamento(aulaId) {
      const aula = await buscarAulaOuErro(aulaId);
      const cancelada = !aula.cancelada;
      const linhas = await obter(cliente().from('aulas')
        .update({ situacao: cancelada ? 'cancelada' : 'ativa' })
        .eq('id', aulaId).select('id'));
      if (!linhas.length) throw new ErroRegra('Aula não encontrada.');
      return cancelada;
    },

    async excluirAula(aulaId) {
      // As inscrições da aula são apagadas junto (on delete cascade).
      await executar(cliente().from('aulas').delete().eq('id', aulaId));
    },

    // --------------------------------------------------------- inscrições

    /** Inscreve o aluno na aula. Todas as regras são aplicadas no banco, de forma atômica. */
    async inscrever(aulaId, alunoId) {
      await executar(cliente().rpc('inscrever', { p_aula_id: aulaId, p_aluno_id: alunoId }));
    },

    async removerInscricao(aulaId, alunoId) {
      const linhas = await obter(cliente().from('inscricoes')
        .delete().eq('aula_id', aulaId).eq('aluno_id', alunoId).select('id'));
      if (!linhas.length) throw new ErroRegra('Não foi possível remover esta inscrição. Atualize a página e tente novamente.');
    },

    async inscritosDaAula(aulaId) {
      const linhas = await obter(cliente().from('inscricoes')
        .select('perfis(id, username, papel, situacao)')
        .eq('aula_id', aulaId));
      return linhas.filter((l) => l.perfis).map((l) => paraUsuario(l.perfis)).sort(porNome);
    },

    async alunosNaoInscritos(aulaId) {
      const [alunos, inscritos] = await Promise.all([this.listarAlunos(), this.inscritosDaAula(aulaId)]);
      const ids = new Set(inscritos.map((u) => u.id));
      return alunos
        .filter((u) => u.ativo && !ids.has(u.id))
        .map(({ totalInscricoes, ...usuario }) => usuario);
    },

    /** Números do painel do administrador. */
    async resumo() {
      const [proximas, contagem] = await Promise.all([
        this.listarAulas({ futuras: true, somenteAtivas: true }),
        executar(cliente().from('perfis').select('id', { count: 'exact', head: true }).eq('papel', 'aluno')),
      ]);
      return {
        proximasAulas: proximas.length,
        vagasOcupadas: proximas.reduce((soma, a) => soma + a.inscritos, 0),
        vagasTotais: proximas.reduce((soma, a) => soma + a.maxAlunos, 0),
        alunos: contagem.count || 0,
      };
    },
  };

  return api;
})();
