-- =============================================================================
-- Arena 847 — Banco de dados no Supabase
-- -----------------------------------------------------------------------------
-- Execute este arquivo inteiro UMA VEZ no Supabase:
--   Painel do projeto → SQL Editor → New query → cole tudo → Run.
--
-- O que ele cria:
--   * perfis      → dados de cada usuário (nome de usuário, papel, situação).
--                   A senha NÃO fica aqui: fica no Supabase Auth (com hash).
--   * aulas       → aulas de Vôlei / Futevôlei.
--   * inscricoes  → quem está inscrito em qual aula (sem duplicidade).
--   * convites    → tabela interna usada só no instante em que o administrador
--                   cria a conta de um aluno (nenhum usuário consegue lê-la).
--   * Funções (RPC) que aplicam as regras do sistema dentro do banco, inclusive
--     a inscrição atômica que nunca deixa o limite de vagas ser ultrapassado.
--   * Políticas de segurança (Row Level Security) para cada tabela.
--
-- Fuso horário usado para saber se uma aula "já aconteceu": America/Sao_Paulo
-- (veja a função public.agora_local, mais abaixo, se precisar mudar).
-- =============================================================================


-- =============================================================================
-- 1. TABELAS
-- =============================================================================

create table if not exists public.perfis (
  id         uuid primary key references auth.users (id) on delete cascade,
  username   text not null check (username ~ '^[A-Za-z0-9._-]{3,30}$'),
  papel      text not null check (papel in ('admin', 'aluno')),
  situacao   text not null default 'ativa' check (situacao in ('ativa', 'desativada')),
  criado_em  timestamptz not null default now()
);

-- Nome de usuário único, sem diferenciar maiúsculas de minúsculas.
create unique index if not exists perfis_username_unico on public.perfis (lower(username));

create table if not exists public.aulas (
  id          bigint generated always as identity primary key,
  modalidade  text not null check (modalidade in ('Vôlei', 'Futevôlei')),
  data        date not null,
  horario     time not null,
  max_alunos  integer not null check (max_alunos between 1 and 100),
  situacao    text not null default 'ativa' check (situacao in ('ativa', 'cancelada')),
  criado_em   timestamptz not null default now()
);

create table if not exists public.inscricoes (
  id         bigint generated always as identity primary key,
  aula_id    bigint not null references public.aulas (id) on delete cascade,
  aluno_id   uuid   not null references public.perfis (id) on delete cascade,
  criado_em  timestamptz not null default now(),
  -- Um aluno não pode se inscrever duas vezes na mesma aula.
  constraint inscricoes_aluno_aula_unica unique (aula_id, aluno_id)
);

create index if not exists inscricoes_aluno_idx on public.inscricoes (aluno_id);

-- Convites de uso único (válidos por 10 minutos) criados pelo administrador
-- no momento de cadastrar um aluno. Sem convite válido, ninguém consegue criar
-- conta pelo navegador (veja a função public.ao_criar_usuario_auth).
create table if not exists public.convites (
  token       uuid primary key default gen_random_uuid(),
  username    text not null,
  papel       text not null default 'aluno' check (papel = 'aluno'),
  criado_por  uuid not null references public.perfis (id) on delete cascade,
  expira_em   timestamptz not null default now() + interval '10 minutes'
);

create unique index if not exists convites_username_unico on public.convites (lower(username));


-- =============================================================================
-- 2. FUNÇÕES AUXILIARES (usadas nas políticas e nas regras)
-- =============================================================================

-- Data e hora atuais no fuso da arena.
create or replace function public.agora_local()
returns timestamp
language sql
stable
set search_path = ''
as $$
  select (now() at time zone 'America/Sao_Paulo');
$$;

-- O usuário logado tem perfil com conta ativa?
create or replace function public.eh_usuario_ativo()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.perfis
    where id = auth.uid() and situacao = 'ativa'
  );
$$;

-- O usuário logado é um administrador com conta ativa?
create or replace function public.eh_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.perfis
    where id = auth.uid() and situacao = 'ativa' and papel = 'admin'
  );
$$;

-- Observação: as mensagens de "raise exception" das funções abaixo são
-- mostradas para o usuário na tela (o JavaScript as transforma em ErroRegra).


-- =============================================================================
-- 3. REGRAS GARANTIDAS PELO PRÓPRIO BANCO (triggers)
-- =============================================================================

-- 3.1 Limite de vagas: vale para QUALQUER inserção em inscricoes.
--     A linha da aula é travada (FOR UPDATE), então duas inscrições
--     simultâneas na mesma aula são processadas uma de cada vez: se só
--     resta uma vaga, apenas uma delas é aceita.
create or replace function public.verificar_limite_inscricao()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_max     integer;
  v_total   integer;
begin
  select max_alunos into v_max
  from public.aulas
  where id = new.aula_id
  for update;

  if not found then
    raise exception 'Aula não encontrada.';
  end if;

  select count(*) into v_total from public.inscricoes where aula_id = new.aula_id;

  if v_total >= v_max then
    raise exception 'Não há mais vagas disponíveis nesta aula.';
  end if;

  return new;
end;
$$;

drop trigger if exists inscricoes_limite_vagas on public.inscricoes;
create trigger inscricoes_limite_vagas
  before insert on public.inscricoes
  for each row execute function public.verificar_limite_inscricao();

-- 3.2 Ao editar uma aula, o limite não pode ficar menor que o número de inscritos.
create or replace function public.verificar_limite_aula()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_total integer;
begin
  if new.max_alunos is distinct from old.max_alunos then
    select count(*) into v_total from public.inscricoes where aula_id = new.id;
    if new.max_alunos < v_total then
      raise exception 'Esta aula já tem % aluno(s) inscrito(s). Remova alunos antes de reduzir as vagas para menos que isso.', v_total;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists aulas_limite_vagas on public.aulas;
create trigger aulas_limite_vagas
  before update on public.aulas
  for each row execute function public.verificar_limite_aula();

-- 3.3 Criação de contas no Supabase Auth.
--     Toda conta nova precisa de um convite válido, gerado pelo administrador
--     (função criar_convite). O perfil do aluno é criado aqui, pelo banco.
--     Exceção: enquanto NÃO existir nenhum administrador (configuração inicial),
--     a conta é aceita mas fica SEM perfil — ou seja, sem acesso a nada — até
--     ser promovida a administrador pelo SQL Editor (veja o README).
create or replace function public.ao_criar_usuario_auth()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_token    uuid;
  v_convite  public.convites%rowtype;
begin
  begin
    v_token := (new.raw_user_meta_data ->> 'convite')::uuid;
  exception when others then
    v_token := null;
  end;

  if v_token is not null then
    select * into v_convite
    from public.convites
    where token = v_token and expira_em > now()
    for update;
  end if;

  if v_convite.token is null then
    if not exists (select 1 from public.perfis where papel = 'admin') then
      return new;  -- configuração inicial: conta sem perfil (sem acesso)
    end if;
    raise exception 'Cadastro não autorizado. Contas são criadas somente pelo administrador.';
  end if;

  if lower(split_part(new.email, '@', 1)) <> lower(v_convite.username) then
    raise exception 'Convite inválido para este usuário.';
  end if;

  insert into public.perfis (id, username, papel)
  values (new.id, v_convite.username, v_convite.papel);

  delete from public.convites where token = v_convite.token;
  return new;
end;
$$;

drop trigger if exists arena_ao_criar_usuario on auth.users;
create trigger arena_ao_criar_usuario
  after insert on auth.users
  for each row execute function public.ao_criar_usuario_auth();


-- =============================================================================
-- 4. FUNÇÕES CHAMADAS PELO SITE (RPC)
-- =============================================================================

-- 4.1 Já existe algum administrador? (usada só pela página de login)
create or replace function public.existe_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (select 1 from public.perfis where papel = 'admin');
$$;

-- 4.2 Aulas com a quantidade de inscritos e se o usuário logado está inscrito.
--     (O aluno não pode ver as inscrições dos outros, mas precisa saber
--     quantas vagas restam: esta função devolve só a contagem.)
create or replace function public.aulas_com_vagas()
returns table (
  id          bigint,
  modalidade  text,
  data        date,
  horario     time,
  max_alunos  integer,
  situacao    text,
  inscritos   integer,
  inscrito    boolean
)
language plpgsql
stable
security definer
set search_path = ''
as $$
begin
  if not public.eh_usuario_ativo() then
    raise exception 'Sua conta está desativada ou a sessão expirou. Entre novamente.';
  end if;

  return query
  select a.id, a.modalidade, a.data, a.horario, a.max_alunos, a.situacao,
         (select count(*)::integer from public.inscricoes i where i.aula_id = a.id),
         exists (select 1 from public.inscricoes i where i.aula_id = a.id and i.aluno_id = auth.uid())
  from public.aulas a;
end;
$$;

-- 4.3 Inscrição atômica. Regras:
--     - conta logada ativa; aluno só inscreve a si mesmo; admin inscreve qualquer aluno ativo;
--     - aula existe, não foi cancelada e ainda não aconteceu;
--     - sem inscrição duplicada;
--     - limite de vagas (a linha da aula fica travada até o fim da operação).
create or replace function public.inscrever(p_aula_id bigint, p_aluno_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_aula public.aulas%rowtype;
  v_total integer;
begin
  if not public.eh_usuario_ativo() then
    raise exception 'Sua conta está desativada ou a sessão expirou. Entre novamente.';
  end if;

  if not public.eh_admin() and p_aluno_id is distinct from auth.uid() then
    raise exception 'Você só pode fazer a sua própria inscrição.';
  end if;

  -- Trava a aula: inscrições simultâneas nesta aula esperam a vez.
  select * into v_aula from public.aulas where id = p_aula_id for update;
  if not found then
    raise exception 'Aula não encontrada.';
  end if;
  if v_aula.situacao = 'cancelada' then
    raise exception 'Esta aula foi cancelada.';
  end if;
  if (v_aula.data + v_aula.horario) <= public.agora_local() then
    raise exception 'Esta aula já aconteceu.';
  end if;

  if not exists (select 1 from public.perfis where id = p_aluno_id and papel = 'aluno') then
    raise exception 'Aluno não encontrado.';
  end if;
  if exists (select 1 from public.perfis where id = p_aluno_id and situacao <> 'ativa') then
    raise exception 'A conta deste aluno está desativada.';
  end if;

  if exists (select 1 from public.inscricoes where aula_id = p_aula_id and aluno_id = p_aluno_id) then
    raise exception 'Este aluno já está inscrito nesta aula.';
  end if;

  select count(*) into v_total from public.inscricoes where aula_id = p_aula_id;
  if v_total >= v_aula.max_alunos then
    raise exception 'Não há mais vagas disponíveis nesta aula.';
  end if;

  insert into public.inscricoes (aula_id, aluno_id) values (p_aula_id, p_aluno_id);
exception
  when unique_violation then
    raise exception 'Este aluno já está inscrito nesta aula.';
end;
$$;

-- 4.4 Convite para o administrador criar a conta de um aluno.
--     Devolve um código de uso único que o site envia junto com o cadastro.
create or replace function public.criar_convite(p_username text)
returns uuid
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  v_nome  text := trim(coalesce(p_username, ''));
  v_token uuid;
begin
  if not public.eh_admin() then
    raise exception 'Somente o administrador pode criar contas.';
  end if;
  if v_nome !~ '^[A-Za-z0-9._-]{3,30}$' then
    raise exception 'O nome de usuário deve ter de 3 a 30 caracteres, usando letras, números, ponto, hífen ou sublinhado (sem espaços e sem acentos).';
  end if;
  if exists (select 1 from public.perfis where lower(username) = lower(v_nome)) then
    raise exception 'Já existe um usuário com esse nome.';
  end if;

  delete from public.convites where expira_em <= now() or lower(username) = lower(v_nome);

  insert into public.convites (username, papel, criado_por)
  values (v_nome, 'aluno', auth.uid())
  returning token into v_token;

  return v_token;
end;
$$;

-- 4.5 Desativar ou reativar a conta de um aluno.
create or replace function public.definir_situacao_aluno(p_aluno_id uuid, p_situacao text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.eh_admin() then
    raise exception 'Somente o administrador pode alterar contas.';
  end if;
  if p_situacao not in ('ativa', 'desativada') then
    raise exception 'Situação inválida.';
  end if;
  update public.perfis set situacao = p_situacao
  where id = p_aluno_id and papel = 'aluno';
  if not found then
    raise exception 'Aluno não encontrado.';
  end if;
end;
$$;

-- 4.6 Excluir a conta de um aluno (login, perfil e inscrições).
create or replace function public.excluir_aluno(p_aluno_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.eh_admin() then
    raise exception 'Somente o administrador pode excluir contas.';
  end if;
  if not exists (select 1 from public.perfis where id = p_aluno_id and papel = 'aluno') then
    raise exception 'Aluno não encontrado.';
  end if;

  begin
    -- Apaga o login no Supabase Auth; perfil e inscrições saem em cascata.
    delete from auth.users where id = p_aluno_id;
  exception when insufficient_privilege then
    -- Se o projeto não permitir apagar em auth.users, apaga o perfil
    -- (e as inscrições). O login fica órfão e sem acesso a nada.
    delete from public.perfis where id = p_aluno_id;
  end;
end;
$$;

-- 4.7 USO SOMENTE NO SQL EDITOR: transforma uma conta do Supabase Auth em
--     administrador. Não pode ser chamada pelo site (permissão revogada abaixo).
create or replace function public.criar_perfil_admin(p_email text, p_username text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_id uuid;
begin
  select id into v_id from auth.users where lower(email) = lower(trim(p_email));
  if v_id is null then
    raise exception 'Nenhuma conta com o e-mail % foi encontrada em Authentication → Users.', p_email;
  end if;
  insert into public.perfis (id, username, papel, situacao)
  values (v_id, trim(p_username), 'admin', 'ativa')
  on conflict (id) do update set username = excluded.username, papel = 'admin', situacao = 'ativa';
end;
$$;


-- =============================================================================
-- 5. SEGURANÇA: ROW LEVEL SECURITY E PERMISSÕES
-- =============================================================================

alter table public.perfis     enable row level security;
alter table public.aulas      enable row level security;
alter table public.inscricoes enable row level security;
alter table public.convites   enable row level security;

-- Visitantes não logados (anon) não acessam nenhuma tabela.
revoke all on public.perfis, public.aulas, public.inscricoes, public.convites from anon;
-- Usuários logados: somente o necessário. Alterações em perfis e convites
-- acontecem apenas pelas funções acima.
revoke all on public.perfis, public.aulas, public.inscricoes, public.convites from authenticated;
grant select                         on public.perfis     to authenticated;
grant select, insert, update, delete on public.aulas      to authenticated;
grant select, delete                 on public.inscricoes to authenticated;

-- perfis: cada um lê o próprio perfil (para o site saber o papel e a situação);
--         o administrador lê todos.
drop policy if exists perfis_leitura on public.perfis;
create policy perfis_leitura on public.perfis
  for select to authenticated
  using (id = auth.uid() or public.eh_admin());

-- aulas: qualquer conta ativa vê; somente o administrador cria, edita e exclui.
drop policy if exists aulas_leitura on public.aulas;
create policy aulas_leitura on public.aulas
  for select to authenticated
  using (public.eh_usuario_ativo());

drop policy if exists aulas_criar on public.aulas;
create policy aulas_criar on public.aulas
  for insert to authenticated
  with check (public.eh_admin());

drop policy if exists aulas_editar on public.aulas;
create policy aulas_editar on public.aulas
  for update to authenticated
  using (public.eh_admin())
  with check (public.eh_admin());

drop policy if exists aulas_excluir on public.aulas;
create policy aulas_excluir on public.aulas
  for delete to authenticated
  using (public.eh_admin());

-- inscricoes: o aluno ativo vê as suas e cancela as suas de aulas que ainda não
--             aconteceram; o administrador vê e remove todas.
--             Novas inscrições só pela função inscrever (não há política de insert).
drop policy if exists inscricoes_leitura on public.inscricoes;
create policy inscricoes_leitura on public.inscricoes
  for select to authenticated
  using (public.eh_admin() or (aluno_id = auth.uid() and public.eh_usuario_ativo()));

drop policy if exists inscricoes_excluir on public.inscricoes;
create policy inscricoes_excluir on public.inscricoes
  for delete to authenticated
  using (
    public.eh_admin()
    or (
      aluno_id = auth.uid()
      and public.eh_usuario_ativo()
      and exists (select 1 from public.aulas a
                  where a.id = aula_id and (a.data + a.horario) > public.agora_local())
    )
  );

-- convites: nenhuma política = ninguém lê ou altera pelo site.

-- Funções: ninguém executa por padrão; libera só o que o site usa.
revoke execute on function
  public.agora_local(),
  public.eh_usuario_ativo(),
  public.eh_admin(),
  public.verificar_limite_inscricao(),
  public.verificar_limite_aula(),
  public.ao_criar_usuario_auth(),
  public.existe_admin(),
  public.aulas_com_vagas(),
  public.inscrever(bigint, uuid),
  public.criar_convite(text),
  public.definir_situacao_aluno(uuid, text),
  public.excluir_aluno(uuid),
  public.criar_perfil_admin(text, text)
from public, anon, authenticated;

grant execute on function public.existe_admin()                       to anon, authenticated;
grant execute on function public.eh_usuario_ativo()                   to authenticated;
grant execute on function public.eh_admin()                           to authenticated;
grant execute on function public.agora_local()                        to authenticated;
grant execute on function public.aulas_com_vagas()                    to authenticated;
grant execute on function public.inscrever(bigint, uuid)              to authenticated;
grant execute on function public.criar_convite(text)                  to authenticated;
grant execute on function public.definir_situacao_aluno(uuid, text)   to authenticated;
grant execute on function public.excluir_aluno(uuid)                  to authenticated;
-- criar_perfil_admin: somente pelo SQL Editor (usuário postgres).


-- =============================================================================
-- 6. TEMPO REAL (as telas se atualizam quando algo muda em outro aparelho)
-- =============================================================================

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables
                   where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'aulas') then
      alter publication supabase_realtime add table public.aulas;
    end if;
    if not exists (select 1 from pg_publication_tables
                   where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'inscricoes') then
      alter publication supabase_realtime add table public.inscricoes;
    end if;
  end if;
end;
$$;

-- Fim. Próximo passo: criar o primeiro administrador (veja o README).
